(async () => {
  await import('./server.mjs');
})();
